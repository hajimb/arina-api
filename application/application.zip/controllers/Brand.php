<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . 'libraries/API_Controller.php';

class Brand extends API_Controller{

    public function __construct(){
        parent::__construct();
        header("Access-Control-Allow-Origin: * ");
        // header("Access-Control-Allow-Headers: * ");
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0,pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->load->model('Brand_model' ,'brand');
    }

    public function index(){
        $this->_apiConfig([
            'methods' => ['GET']
        ]); 
        $result = $this->brand->getBrand($_POST);
        // print_r($result);exit;
        $this->api_return([
            'status'   => TRUE,
            'validate' => TRUE,
            'data'     => $result
        ], '200');
    }
}