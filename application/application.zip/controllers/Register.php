<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . 'libraries/API_Controller.php';

class Register extends API_Controller{

    public function __construct(){
        parent::__construct();
        header("Access-Control-Allow-Origin: * ");
        // header("Access-Control-Allow-Headers: * ");
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0,pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->load->model('Register_model' ,'register');
        $this->load->library('Authorization_Token','authorization_token');
    }

    /*
    1.  HTTP_OK
    2.  HTTP_BAD_REQUEST
    2.  HTTP_NOT_FOUND
    */

    public function index(){
        $verror = array();
        $content = trim(file_get_contents('php://input'));
        $_POST = json_decode($content, true );

        $this->_apiConfig([
            'methods' => ['POST']
        ]); 
        

        $id     = trim($this->input->post('id')) && 0;
        $this->form_validation->set_rules('firstname', 'First Name', 'required|trim');
        $this->form_validation->set_rules('lastname', 'Last Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('telephone', 'Contact Number', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        $this->form_validation->set_rules('confirm', 'Confirm Password', 'required|trim');
        $this->form_validation->set_rules('confirm', 'Confirm Password', 'required|matches[password]');
        $this->form_validation->set_rules('newsletter', 'Confirm Password', 'required|trim');
        

        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_message('required', 'Enter %s');
        if ($this->form_validation->run()) {
            $salt   = token(9);
            $password = $this->input->post('password');
            $telephone = $this->input->post('telephone');
            $hashpassword = sha1($salt . sha1($salt . sha1($password)));
            $master = array(
                'customer_group_id' => CUSTOMER_GROUP_ID,
                'store_id'          => STORE_ID,
                'LANGUAGE_ID'       => LANGUAGE_ID,
                'firstname'         => $this->input->post('firstname'),
                'lastname'          => $this->input->post('lastname'),
                'email'             => $this->input->post('email'),
                'telephone'         => $telephone,
                'custom_field'      => CUSTOM_FIELD,
                'salt'              => $salt,
                'password'          => $hashpassword,
                'newsletter'        => $this->input->post('newsletter'),
                'ip'                => getIPAddress(),
                'status'            => STATUS,
                'date_added'        => currDate(),
            );
            
            $this->register->_condition['telephone']  = $telephone;
            $result = $this->register->saveData($master, $id);
            
            $this->api_return([
                'status'   => $result['status'],
                'validate' => TRUE,
                'message'  => 'User '.$result['msg'],
            ], '200');
        } else {
            foreach ($_POST as $key => $value) {
                $verror[$key] = form_error($key);
            }

            $this->api_return([
                'status'   => FALSE,
                'validate' => FALSE,
                'message'  => $verror,
            ], '200');
        }
    }

    public function update(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );
        $token = $this->authorization_token->validateToken();
        if($token['status']){
            $userData = $token['data'];
            $id= $userData->id;
            $this->_apiConfig(['methods' => ['POST']]); 

            $this->form_validation->set_rules('firstname', 'First Name', 'required|trim');
            $this->form_validation->set_rules('lastname', 'Last Name', 'required|trim');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
            $this->form_validation->set_rules('telephone', 'Contact Number', 'required|trim');

            $this->form_validation->set_error_delimiters('', '');
            $this->form_validation->set_message('required', 'Enter %s');

            if ($this->form_validation->run()) {
                $salt   = token(9);
                $password       = $this->input->post('password');
                $telephone      = $this->input->post('telephone');
                $hashpassword   = sha1($salt . sha1($salt . sha1($password)));
                $master = array(
                    'firstname' => $this->input->post('firstname'),
                    'lastname'  => $this->input->post('lastname'),
                    'email'     => $this->input->post('email'),
                    'telephone' => $telephone
                );
                
                $result = $this->register->saveData($master, $id);
                
                $this->api_return([
                    'status'   => $result['status'],
                    'validate' => TRUE,
                    'message'  => 'User '.$result['msg'],
                ], '200');
            } else {
                foreach ($_POST as $key => $value) {
                    $verror[$key] = form_error($key);
                }
                $this->api_return([
                    'status'   => FALSE,
                    'validate' => FALSE,
                    'message'  => $verror,
                ], '200');
            }
        }else{
            $this->api_return([
                    'status'   => FALSE,
                    'validate' => TRUE,
                    'message'  => 'User '.$token['message'],
                ], '200');
        }
    }


    
}