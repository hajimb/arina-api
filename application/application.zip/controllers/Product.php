<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . 'libraries/API_Controller.php';

class Product extends API_Controller{

    public function __construct(){
        parent::__construct();
        header("Access-Control-Allow-Origin: * ");
        // header("Access-Control-Allow-Headers: * ");
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0,pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->load->model('Product_model' ,'product');
    }

    public function index(){
        $this->_apiConfig([
            'methods' => ['GET']
        ]); 
        $data = array('filter_category_id' =>477);
        $result = $this->product->getProducts($data);
        // print_r($result);exit;
        $this->api_return([
            'status'   => TRUE,
            'validate' => TRUE,
            'data'     => $result
        ], '200');
    }
}