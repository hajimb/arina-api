<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . 'libraries/API_Controller.php';

class Password extends API_Controller{

    public function __construct(){
        parent::__construct();
        header("Access-Control-Allow-Origin: *");
        // header("Access-Control-Allow-Headers: * ");
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0,pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->load->model('Password_model' ,'password');
        $this->load->library('bcrypt');
        $this->load->library('Authorization_Token','authorization_token');
    }

    /*
    1.  HTTP_OK
    2.  HTTP_BAD_REQUEST
    2.  HTTP_NOT_FOUND
    */
   
    // Reset Password
    public function forgotPassword(){
        $verror = array();
        $content = trim(file_get_contents('php://input'));
        $_POST = json_decode($content, true );
        // $_POST = json_decode(file_get_contents("php://input"), true);
        //  echo json_encode($_POST);
        
        $client = $this->input->post('client') ??  'app';
        $reqHeader = $this->input->request_headers();

        $UserAgent = $reqHeader['User-Agent'];
        if(strpos($UserAgent, 'Postman') !== false){
            $client = 'postman';
        } 
        // print_r($_POST);
        // exit();
        $this->_apiConfig([
            'methods' => ['POST'],
            /**
             * Number Limit, type limit, time limit (last minute)
             */
            'limit' =>[100, 'ip', 'everyday'],
        ]); 
        
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('login_type', 'Login Type', 'required|trim');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_message('required', 'Enter %s');
        if ($this->form_validation->run()) {
            $_POST['randomno'] = rand ( 1000 , 9999 );
            $result = $this->password->CheckUsername($_POST);
            // print_r($result);exit;
            $this->api_return([
                'status'   => $result['status'],
                'validate' => TRUE,
                'message'  => $result['msg'],
                'data'     => array('user_id' => $result['user_id'], 'otp' => $_POST['randomno'])
            ], '200');
        } else {
            foreach ($this->input->post() as $key => $value) {
                $verror[$key] = form_error($key);
            }

            $this->api_return([
                'status'   => FALSE,
                'validate' => FALSE,
                'message'  => $verror,
            ], '200');
        }
    }

    public function changePassword(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );
        $token   = $this->authorization_token->validateToken();
        if($token['status']){
            $userData = $token['data'];
            $id       = $userData->id;
            $email    = $userData->email;
            $this->_apiConfig(['methods' => ['POST']]); 

            $this->form_validation->set_rules('password', 'First Name', 'required|trim');
            $this->form_validation->set_rules('confirm', 'Last Name', 'required|trim');
            $this->form_validation->set_rules('confirm', 'Confirm Password', 'required|matches[password]');

            $this->form_validation->set_error_delimiters('', '');
            $this->form_validation->set_message('required', 'Enter %s');

            if ($this->form_validation->run()) {
                $salt           = token(9);
                $password       = $this->input->post('password');
                $hashpassword   = sha1($salt . sha1($salt . sha1($password)));

                // echo $salt;
                // echo $hashpassword;
                $master = array(
                    'password' => $hashpassword,
                    'salt'     => $salt
                );
                
                $result = $this->password->changepassword($email, $master, $id);
                
                $this->api_return([
                    'status'   => $result['status'],
                    'validate' => TRUE,
                    'message'  => 'User '.$result['msg'],
                ], '200');
            } else {
                foreach ($_POST as $key => $value) {
                    $verror[$key] = form_error($key);
                }
                $this->api_return([
                    'status'   => FALSE,
                    'validate' => FALSE,
                    'message'  => $verror,
                ], '200');
            }
        }else{
            $this->api_return([
                    'status'   => FALSE,
                    'validate' => TRUE,
                    'message'  => 'User '.$token['message'],
                ], '200');
        }
    }
}