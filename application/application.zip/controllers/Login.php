<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . 'libraries/API_Controller.php';

class Login extends API_Controller{

    public function __construct(){
        parent::__construct();
        header("Access-Control-Allow-Origin: * ");
        // header("Access-Control-Allow-Headers: * ");
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0,pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->load->model('Login_model' ,'login');
    }

    public function index(){
       
        $verror = array();
        $content = trim(file_get_contents('php://input'));
        $_POST = json_decode($content, true );

        // echo $client;
        // print_r($_POST);
        // echo '<pre />';
        
        $this->_apiConfig([
            'methods' => ['POST'],
            
        ]); 
        // $this->form_validation->set_data($_POST);
        $this->form_validation->set_rules('username', 'Username', 'required|valid_email|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]|trim');

        // $this->form_validation->set_rules('fcm_id', 'FCM ID', 'required|trim');
        // $this->form_validation->set_rules('device_id', 'Device ID', 'required|trim');

        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_message('required', 'Enter %s');
        if ($this->form_validation->run()) {
            
            $result = $this->login->index($_POST);
            // print_r($result);exit;
            $this->api_return([
                'status'   => $result['status'],
                'validate' => TRUE,
                'message'  => $result['msg'],
                'data'     => $result['data'],
            ], '200');
            // print_r($result);exit;
        } else {
            foreach ($_POST as $key => $value) {
                $verror[$key] = form_error($key);
            }

            $this->api_return([
                'status'   => FALSE,
                'validate' => FALSE,
                'message'  => $verror,
                'error'  => validation_errors(),
            ], '200');
        }
    }
}