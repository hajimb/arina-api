<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . 'libraries/API_Controller.php';

class User extends API_Controller{

    public function __construct(){
        parent::__construct();
        header("Access-Control-Allow-Origin: * ");
        // header("Access-Control-Allow-Headers: * ");
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0,pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->load->model('User_model' ,'user');
        $this->load->library('Authorization_Token','authorization_token');
    }

    /*
    1.  HTTP_OK
    2.  HTTP_BAD_REQUEST
    2.  HTTP_NOT_FOUND
    */
        // Array ( [firstname] => Sheikh [lastname] => Arshad [address_1] => fsdfdsf sdfsd fdsf [address_2] => [city] => Thane [postcode] => 401107 [country_id] => 114 [zone_id] => 1788 [default] => 0 )

    public function getAddressById(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );
        $token   = $this->authorization_token->validateToken();
        if($token['status']){
            $userData = $token['data'];
            $id       = $userData->id;
            
            $this->_apiConfig(['methods' => ['POST']]); 
            $this->form_validation->set_rules('address_id', 'address_id', 'required|trim');

            $this->form_validation->set_error_delimiters('', '');
            $this->form_validation->set_message('required', 'Enter %s');

            if ($this->form_validation->run()) {
                $address_id = $this->input->post('address_id');
                $where      = array( 'customer_id' => $id, 'address_id'=> $address_id);
                $result     = $this->user->getAddressById($where);
                $this->api_return([
                    'status'   => TRUE,
                    'validate' => TRUE,
                    'data'      => $result,
                ], '200');
            } else {
                foreach ($_POST as $key => $value) {
                    $verror[$key] = form_error($key);
                }
                $this->api_return([
                    'status'   => FALSE,
                    'validate' => FALSE,
                    'message'  => $verror,
                ], '200');
            }
        }else{
            $this->api_return([
                'status'   => FALSE,
                'validate' => TRUE,
                'message'  => 'User '.$token['message'],
            ], '200');
        }
    }

    public function deleteAddress(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );
        $token   = $this->authorization_token->validateToken();
        if($token['status']){
            $userData = $token['data'];
            $id       = $userData->id;
            $this->_apiConfig(['methods' => ['POST']]); 
            $this->form_validation->set_rules('address_id', 'address_id', 'required|trim');
            $this->form_validation->set_error_delimiters('', '');
            $this->form_validation->set_message('required', 'Enter %s');
            if ($this->form_validation->run()) {
                $address_id = $this->input->post('address_id');
                $where      = array( 'customer_id' => $id, 'address_id'=> $address_id);
                $result     = $this->user->deleteAddress($where);
                $this->api_return([
                    'status'   => TRUE,
                    'validate' => TRUE,
                    'data'      => $result,
                ], '200');
            } else {
                foreach ($_POST as $key => $value) {
                    $verror[$key] = form_error($key);
                }
                $this->api_return([
                    'status'   => FALSE,
                    'validate' => FALSE,
                    'message'  => $verror,
                ], '200');
            }
        }else{
            $this->api_return([
                'status'   => FALSE,
                'validate' => TRUE,
                'message'  => 'User '.$token['message'],
            ], '200');
        }
    }

    public function addAddress(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );

        $token   = $this->authorization_token->validateToken();
        if($token['status']){
            $userData = $token['data'];
            $id       = $userData->id;
            $email    = $userData->email;
            $where = array('email' => $email, 'customer_id' => $id);
            $this->_apiConfig(['methods' => ['POST']]); 

            $this->form_validation->set_rules('firstname', 'First Name', 'required|trim');
            $this->form_validation->set_rules('lastname', 'Last Name', 'required|trim');
            $this->form_validation->set_rules('address_1', 'Address 1', 'required|trim');
            $this->form_validation->set_rules('address_2', 'Address 2', 'required|trim');
            $this->form_validation->set_rules('city', 'City', 'required|trim');
            $this->form_validation->set_rules('postcode', 'Postcode', 'required|trim');
            $this->form_validation->set_rules('country_id', 'Country', 'required|trim');
            $this->form_validation->set_rules('zone_id', 'Zone', 'required|trim');
            $this->form_validation->set_rules('default', 'default', 'required|trim');
            $this->form_validation->set_rules('address_id', 'address_id', 'required|trim');

            $this->form_validation->set_error_delimiters('', '');
            $this->form_validation->set_message('required', 'Enter %s');

            if ($this->form_validation->run()) {
                $address_id = $this->input->post('address_id') ?? 0;
                $master = array(
                    'firstname'     => $this->input->post('firstname'),
                    'lastname'      => $this->input->post('lastname'),
                    'address_1'     => $this->input->post('address_1'),
                    'address_2'     => $this->input->post('address_2'),
                    'city'          => $this->input->post('city'),
                    'postcode'      => $this->input->post('postcode'),
                    'country_id'    => $this->input->post('country_id'),
                    'zone_id'       => $this->input->post('zone_id'),
                    'customer_id'   => $id,
                    'default'       => $this->input->post('default') ?? 0,
                );
                $result = $this->user->addAddress($master, $where, $address_id);
                $this->api_return([
                    'status'   => $result['status'],
                    'validate' => TRUE,
                    'message'  => 'User '.$result['msg'],
                ], '200');
            } else {
                foreach ($_POST as $key => $value) {
                    $verror[$key] = form_error($key);
                }
                $this->api_return([
                    'status'   => FALSE,
                    'validate' => FALSE,
                    'message'  => $verror,
                ], '200');
            }
        }else{
            $this->api_return([
                'status'   => FALSE,
                'validate' => TRUE,
                'message'  => 'User '.$token['message'],
            ], '200');
        }
    }

    public function getAddress(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );
        $token   = $this->authorization_token->validateToken();
        if($token['status']){
            $userData = $token['data'];
            $id       = $userData->id;
            $email    = $userData->email;
            $this->_apiConfig(['methods' => ['GET']]); 

            $result = $this->user->getAddress($id);
            $this->api_return([
                'status'   => True,
                'validate' => TRUE,
                'data'  => $result,
            ], '200');
            
        }else{
            $this->api_return([
                'status'   => FALSE,
                'validate' => TRUE,
                'message'  => 'User '.$token['message'],
            ], '200');
        }
    }

    public function getCountry(){
        $verror  = array();
        $this->_apiConfig(['methods' => ['GET']]); 
        $result = $this->user->getCountry();
        $this->api_return([
            'status'   => True,
            'validate' => TRUE,
            'data'  => $result,
        ], '200');
    }


    public function getZones(){
        $verror  = array();
        $content = trim(file_get_contents('php://input'));
        $_POST   = json_decode($content, true );
        $this->_apiConfig(['methods' => ['POST']]); 
        $this->form_validation->set_rules('country_id', 'Country', 'required|trim');
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_message('required', 'Enter %s');
        if ($this->form_validation->run()) {
            $country_id = $this->input->post('country_id');
            $result = $this->user->getZones($country_id);
            $this->api_return([
                'status'   => TRUE,
                'validate' => TRUE,
                'message'  => $result,
            ], '200');
        } else {
            foreach ($_POST as $key => $value) {
                $verror[$key] = form_error($key);
            }
            $this->api_return([
                'status'   => FALSE,
                'validate' => FALSE,
                'message'  => $verror,
            ], '200');
        }
        
    }
}