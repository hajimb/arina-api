<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Login_model extends MY_Model
{
    public $table;
    public function __construct() {
        parent::__construct();
        // Load Authorization Library or Load in autoload config file
        $this->load->library('Authorization_Token','authorization_token');
        $this->load->helper('string');
        $this->load->library('bcrypt');
        $this->table = 'oc_customer';
    }

    public function index(array $data){
        
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('email', $data['username']);

        $query   = $this->db->get();
        $numrows = $query->num_rows(); 
        // print $this->db->last_query();
        if ($numrows === 1) {
            $row = $query->row();
            
            $salt           = $row->salt;
            $password       = $data['password'];
            $hashpassword   = sha1($salt . sha1($salt . sha1($password)));
            // echo $hashpassword;

                $checkpassword = $this->checkpassword($hashpassword, $row->password);
                if ($checkpassword == 1) {
                    // you user authentication code will go here, you can compare the user with the database or whatever
                    $secretKey = $this->bcrypt->hash_password(random_string('alnum', 8));
                    $payload = [
                        'id'         => $row->customer_id,
                        'email'      => $row->email,
                        'secretKey'  => $secretKey,
                        'mobile'     => $row->telephone,
                    ];
                    $token = $this->authorization_token->generateToken($payload);
                    $sessionData = array(
                        'email'     => $row->email,
                        'mobile'    => $row->telephone,
                        'firstname' => $row->firstname,
                        'lastname'  => $row->lastname,
                        'token'     => $token,
                    );

                    $result = array('msg' => 'Successfully Login!', 'status' => true, 'success' => true, 'data'=> $sessionData);
                } else {
                    $result = array('msg' => 'Incorrect Password!', 'status' => false, 'success' => true, 'data'=> '');
                }
           
        } else {
            $result = array('msg' => 'No Record Found!', 'status' => false, 'success' => true, 'data' => '');
        }
        return $result;
    }  

    

    public function checkpassword($hashpassword, $dbpassword){
        if ($hashpassword === $dbpassword) {
            return 1;
        } else {
            return 0;
        }
    }
}
