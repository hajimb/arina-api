<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Password_model extends MY_Model
{

    public $table;
    public $_primary_key;
    public $_condition;
    public function __construct() {
        parent::__construct();
        $this->table = 'oc_customer';
        $this->_primary_key = 'id';
        $this->_condition = array();
        $this->load->library('bcrypt');
    }    

    public function CheckUsername(array $data){
        $this->setTable($data);
        $this->db->select('id');
        $this->db->where('mobile_number', $data['username']);
        $this->db->or_where('email_id', $data['username']);
        $query = $this->db->get($this->table);

        $row = $query->num_rows(); 
        if($row > 0) {
            $row     = $query->row();
            $user_id = $row->id;
            // echo 'OTP : '.$otp;
            $update  = array('random_no' => $data['randomno']);
            $this->db->where('id', $user_id);
            $this->db->update($this->table, $update);
            // pr =>nt $this->db->last_query();exit();
            $error = $this->db->error();
            if($error['code'] == 0){
                return array('status' => true, 'msg' => 'Record Found', 'user_id' => $user_id);
            }else{
                return array('status' => false, 'msg' => $error['message'], 'user_id' => null);
            }
        } else {
            return array('status' => false, 'msg' => "Record Not Found", 'user_id' => null);
        }
    }

    private function setTable($data){
        if($data['login_type'] == 'user'){
            $this->table = 'master_users';
        }else if($data['login_type'] == 'broadcaster'){
            $this->table = 'master_broadcaster';
        }else if($data['login_type'] == 'agency'){
            $this->table = 'master_agency';
        }
    }

    private function checkpassword($password, $stored_hash){
        if ($this->bcrypt->check_password($password, $stored_hash)) {
            return 1;
        } else {
            return 0;
        }
    }

    public function changepassword($email, $master, $id){
        $this->db->where('customer_id', $id);
        $this->db->where('email', $email);
        $this->db->update($this->table, $master);
        $error = $this->db->error();
        if($error['code'] == 0){
            return array('msg' => 'Password Successfully Change', 'status' => true, 'success' => true);
        }else{
            return array('msg' => 'Error On Updating Passsword', 'status' => false, 'success' => true);
        }
    }
}