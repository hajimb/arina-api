<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Brand_model extends CI_Model
{

    public $table;
    public $_primary_key;
    public $_condition;
    public function __construct() {
        parent::__construct();
        
    }    

    public function getBrand(){
        $sql = "SELECT * FROM oc_category c LEFT JOIN oc_category_description cd ON (c.category_id = cd.category_id) LEFT JOIN oc_category_to_store c2s ON (c.category_id = c2s.category_id) WHERE cd.language_id = '1' AND c2s.store_id = '0' AND c.status = '1' AND c.featured = '1' ORDER BY c.sort_order, LCASE(cd.name) LIMIT 10";
        $runQuery = $this->db->query($sql);
        return $runQuery->result_array();
    }

    
}